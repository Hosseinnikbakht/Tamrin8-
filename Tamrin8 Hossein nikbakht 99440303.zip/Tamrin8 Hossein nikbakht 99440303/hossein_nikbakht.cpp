
#include<iostream>
#include<fstream>
#include<string>
using namespace std;
//hossein_nikbakht
int n;
struct product_info
{
	int id = 0;
	string name = "";
	int price = 0;
	int count = 0;
}*products;
int menu();
void show_list();
void load();
void write();
int main()
{
	
	int choice = 0;
	/*cout << "Enter number products: ";
	cin >> n;*/
	write();//n=3 dar in tabe barymesal 3 khat dade dar file zakhire mishavad
	products = new product_info[n];
	
	while (choice!=7)
	{
		
		load();
		choice = menu();
		switch (choice)
		{
		case 1:			
			break;
		case 2:
			break;
		case 3:
			break;
		case 4:
			break;
		case 5:
			show_list();
			break;
		case 6:
			break;
		case 7:
			cout << "End." << endl;
			break;
		default:
			cout << "The number entered id out of the menu! Try again"<<endl;
			break;
		}
		system("pause");
		system("cls");
	}
	delete[] products;
    return 0;
}



void load()
{
	string line;
	ifstream Product_info;
	Product_info.open("products.txt");
	int k = 0;
	while (getline(Product_info, line))
	{
		string array[4];
		int j = 0;
		for (int i = 0; i <= line.length(); i++)
		{
			if (line[i] != ',' && line[i]!=NULL)
				array[j] = array[j] + line[i];
			else
			{
				switch (j)
				{
				case 0:
					products[k].id = stoi(array[j]);
					break;
				case 1:
					products[k].name = array[j];
					break;
				case 2:
					products[k].price = stoi(array[j]);
					break;
				case 3:
					products[k].count = stoi(array[j]);
					break;
				}
				j++;
			}
		}
		k++;
	}
	Product_info.close();
}
void write()
{
	ofstream Product_info;
	Product_info.open("products.txt");
	Product_info << "100,apple,30000,40" << endl;
	Product_info << "101,mango,40000,20" << endl;
	Product_info << "103,watermelone,5000,100";
	n = 3;
	Product_info.close();
}

void show_list()
{
	for (int i = 0; i < n; i++)
		cout << "\nProduct " << i + 1 << ": id:" << products[i].id << "\tname:" << products[i].name << "\tprice:" << products[i].price << "\tcount:" << products[i].count;
	cout << endl;
}

int menu()
{
	int choice;
	cout << "\n\t STORE MENU\n1-Add Product\n2-Edit Product\n3-Delete Product\n4-Search\n5-Show list\n6-Buy\n7-Exit\nEnter your choice: ";
	cin >> choice;
	return choice;
}


